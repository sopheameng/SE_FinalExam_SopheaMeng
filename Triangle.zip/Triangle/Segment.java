package Triangle;

public class Segment {
    private Point p1;
    private Point p2;

    public Segment(){}
    public Segment(Point p1, Point p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    public float lenght(){
        float distant = (float) Math.sqrt(Math.pow((p2.getX()-p1.getX()),2) + Math.pow((p2.getY() - p1.getY()),2));
        return distant;
    }
}
 


