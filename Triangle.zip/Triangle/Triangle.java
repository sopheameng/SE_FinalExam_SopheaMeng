package Triangle;

public class Triangle {

    
    private Segment AB;
    private Segment BC;
    private Segment CA;

    public Triangle(Segment AB, Segment BC, Segment CA) {
        this.AB = AB;
        this.BC = BC;
        this.CA = CA;
    }
    public float perimeter(){
        float p = AB.lenght() + BC.lenght() + CA.lenght();
        return p;
    }

    public static void main(String[] args) {
        float perimeter;

        Point A= new Point(1,3);
        Point B= new Point(5,2);
        Point C= new Point(4,2);
        Segment AB = new Segment(A,B);
        Segment BC = new Segment(B,C);
        Segment CA = new Segment(C,A);
        Triangle ABC = new Triangle(AB,BC,CA);
        perimeter = ABC.perimeter();
        System.out.println("The perimeter of a triangle is: " +perimeter);
        


    }
}